﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EMPLOYEE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Search = New System.Windows.Forms.Label()
        Me.DGVEMPLOYEE = New System.Windows.Forms.DataGridView()
        Me.SAVEEMPLOYEE = New System.Windows.Forms.Button()
        Me.ADDEMPLOYEE = New System.Windows.Forms.Button()
        Me.SEARCHEMPLOYEE = New System.Windows.Forms.TextBox()
        Me.Panel2CAR = New System.Windows.Forms.Panel()
        Me.EMPTEL = New System.Windows.Forms.TextBox()
        Me.EMPADDRESS = New System.Windows.Forms.TextBox()
        Me.EMPID = New System.Windows.Forms.TextBox()
        Me.EMPEMAIL = New System.Windows.Forms.TextBox()
        Me.EMPMNAME = New System.Windows.Forms.TextBox()
        Me.EMPLNAME = New System.Windows.Forms.TextBox()
        Me.LabelTNCAR = New System.Windows.Forms.Label()
        Me.LabelACAR = New System.Windows.Forms.Label()
        Me.LabelECAR = New System.Windows.Forms.Label()
        Me.LabelLNCAR = New System.Windows.Forms.Label()
        Me.LabelMNCAR = New System.Windows.Forms.Label()
        Me.LabelFNCAR = New System.Windows.Forms.Label()
        Me.LabelPNRNCAR = New System.Windows.Forms.Label()
        Me.EMPFNAME = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DELETEMPLOYEE = New System.Windows.Forms.Button()
        Me.EMPBACK = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.DGVEMPLOYEE, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2CAR.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Search
        '
        Me.Search.AutoSize = True
        Me.Search.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Search.Location = New System.Drawing.Point(21, 297)
        Me.Search.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(149, 26)
        Me.Search.TabIndex = 58
        Me.Search.Text = "Search Emp ID:"
        '
        'DGVEMPLOYEE
        '
        Me.DGVEMPLOYEE.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DGVEMPLOYEE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVEMPLOYEE.Location = New System.Drawing.Point(12, 335)
        Me.DGVEMPLOYEE.Margin = New System.Windows.Forms.Padding(2)
        Me.DGVEMPLOYEE.Name = "DGVEMPLOYEE"
        Me.DGVEMPLOYEE.RowTemplate.Height = 24
        Me.DGVEMPLOYEE.Size = New System.Drawing.Size(1116, 278)
        Me.DGVEMPLOYEE.TabIndex = 57
        '
        'SAVEEMPLOYEE
        '
        Me.SAVEEMPLOYEE.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SAVEEMPLOYEE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAVEEMPLOYEE.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SAVEEMPLOYEE.Location = New System.Drawing.Point(802, 296)
        Me.SAVEEMPLOYEE.Name = "SAVEEMPLOYEE"
        Me.SAVEEMPLOYEE.Size = New System.Drawing.Size(75, 33)
        Me.SAVEEMPLOYEE.TabIndex = 59
        Me.SAVEEMPLOYEE.Text = "Save"
        Me.SAVEEMPLOYEE.UseVisualStyleBackColor = False
        '
        'ADDEMPLOYEE
        '
        Me.ADDEMPLOYEE.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ADDEMPLOYEE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDEMPLOYEE.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ADDEMPLOYEE.Location = New System.Drawing.Point(721, 296)
        Me.ADDEMPLOYEE.Name = "ADDEMPLOYEE"
        Me.ADDEMPLOYEE.Size = New System.Drawing.Size(75, 33)
        Me.ADDEMPLOYEE.TabIndex = 55
        Me.ADDEMPLOYEE.Text = "Add"
        Me.ADDEMPLOYEE.UseVisualStyleBackColor = False
        '
        'SEARCHEMPLOYEE
        '
        Me.SEARCHEMPLOYEE.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEARCHEMPLOYEE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEARCHEMPLOYEE.Location = New System.Drawing.Point(177, 301)
        Me.SEARCHEMPLOYEE.Name = "SEARCHEMPLOYEE"
        Me.SEARCHEMPLOYEE.Size = New System.Drawing.Size(377, 22)
        Me.SEARCHEMPLOYEE.TabIndex = 60
        '
        'Panel2CAR
        '
        Me.Panel2CAR.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.Panel2CAR.Controls.Add(Me.EMPTEL)
        Me.Panel2CAR.Controls.Add(Me.EMPADDRESS)
        Me.Panel2CAR.Controls.Add(Me.EMPID)
        Me.Panel2CAR.Controls.Add(Me.EMPEMAIL)
        Me.Panel2CAR.Controls.Add(Me.EMPMNAME)
        Me.Panel2CAR.Controls.Add(Me.EMPLNAME)
        Me.Panel2CAR.Controls.Add(Me.LabelTNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelACAR)
        Me.Panel2CAR.Controls.Add(Me.LabelECAR)
        Me.Panel2CAR.Controls.Add(Me.LabelLNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelMNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelFNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelPNRNCAR)
        Me.Panel2CAR.Controls.Add(Me.EMPFNAME)
        Me.Panel2CAR.Location = New System.Drawing.Point(12, 115)
        Me.Panel2CAR.Name = "Panel2CAR"
        Me.Panel2CAR.Size = New System.Drawing.Size(1118, 168)
        Me.Panel2CAR.TabIndex = 56
        '
        'EMPTEL
        '
        Me.EMPTEL.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPTEL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPTEL.Location = New System.Drawing.Point(761, 91)
        Me.EMPTEL.Name = "EMPTEL"
        Me.EMPTEL.Size = New System.Drawing.Size(340, 22)
        Me.EMPTEL.TabIndex = 36
        '
        'EMPADDRESS
        '
        Me.EMPADDRESS.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPADDRESS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPADDRESS.Location = New System.Drawing.Point(671, 52)
        Me.EMPADDRESS.Name = "EMPADDRESS"
        Me.EMPADDRESS.Size = New System.Drawing.Size(430, 22)
        Me.EMPADDRESS.TabIndex = 35
        '
        'EMPID
        '
        Me.EMPID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPID.Location = New System.Drawing.Point(165, 13)
        Me.EMPID.Name = "EMPID"
        Me.EMPID.Size = New System.Drawing.Size(379, 22)
        Me.EMPID.TabIndex = 34
        '
        'EMPEMAIL
        '
        Me.EMPEMAIL.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPEMAIL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPEMAIL.Location = New System.Drawing.Point(671, 13)
        Me.EMPEMAIL.Name = "EMPEMAIL"
        Me.EMPEMAIL.Size = New System.Drawing.Size(430, 22)
        Me.EMPEMAIL.TabIndex = 33
        '
        'EMPMNAME
        '
        Me.EMPMNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPMNAME.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPMNAME.Location = New System.Drawing.Point(165, 91)
        Me.EMPMNAME.Name = "EMPMNAME"
        Me.EMPMNAME.Size = New System.Drawing.Size(379, 22)
        Me.EMPMNAME.TabIndex = 32
        '
        'EMPLNAME
        '
        Me.EMPLNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPLNAME.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPLNAME.Location = New System.Drawing.Point(165, 127)
        Me.EMPLNAME.Name = "EMPLNAME"
        Me.EMPLNAME.Size = New System.Drawing.Size(379, 22)
        Me.EMPLNAME.TabIndex = 31
        '
        'LabelTNCAR
        '
        Me.LabelTNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelTNCAR.Location = New System.Drawing.Point(565, 87)
        Me.LabelTNCAR.Name = "LabelTNCAR"
        Me.LabelTNCAR.Size = New System.Drawing.Size(229, 26)
        Me.LabelTNCAR.TabIndex = 30
        Me.LabelTNCAR.Text = "Telephone Number:"
        '
        'LabelACAR
        '
        Me.LabelACAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelACAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelACAR.Location = New System.Drawing.Point(565, 48)
        Me.LabelACAR.Name = "LabelACAR"
        Me.LabelACAR.Size = New System.Drawing.Size(138, 26)
        Me.LabelACAR.TabIndex = 29
        Me.LabelACAR.Text = "Address:"
        '
        'LabelECAR
        '
        Me.LabelECAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelECAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelECAR.Location = New System.Drawing.Point(565, 9)
        Me.LabelECAR.Name = "LabelECAR"
        Me.LabelECAR.Size = New System.Drawing.Size(86, 26)
        Me.LabelECAR.TabIndex = 28
        Me.LabelECAR.Text = "Email:"
        '
        'LabelLNCAR
        '
        Me.LabelLNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelLNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelLNCAR.Location = New System.Drawing.Point(9, 123)
        Me.LabelLNCAR.Name = "LabelLNCAR"
        Me.LabelLNCAR.Size = New System.Drawing.Size(131, 26)
        Me.LabelLNCAR.TabIndex = 27
        Me.LabelLNCAR.Text = "Last Name:"
        '
        'LabelMNCAR
        '
        Me.LabelMNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelMNCAR.Location = New System.Drawing.Point(10, 87)
        Me.LabelMNCAR.Name = "LabelMNCAR"
        Me.LabelMNCAR.Size = New System.Drawing.Size(171, 26)
        Me.LabelMNCAR.TabIndex = 26
        Me.LabelMNCAR.Text = "Middle Name:"
        '
        'LabelFNCAR
        '
        Me.LabelFNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelFNCAR.Location = New System.Drawing.Point(9, 48)
        Me.LabelFNCAR.Name = "LabelFNCAR"
        Me.LabelFNCAR.Size = New System.Drawing.Size(130, 26)
        Me.LabelFNCAR.TabIndex = 25
        Me.LabelFNCAR.Text = "First Name:"
        '
        'LabelPNRNCAR
        '
        Me.LabelPNRNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPNRNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelPNRNCAR.Location = New System.Drawing.Point(11, 9)
        Me.LabelPNRNCAR.Name = "LabelPNRNCAR"
        Me.LabelPNRNCAR.Size = New System.Drawing.Size(111, 26)
        Me.LabelPNRNCAR.TabIndex = 24
        Me.LabelPNRNCAR.Text = "Emp ID:"
        '
        'EMPFNAME
        '
        Me.EMPFNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPFNAME.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPFNAME.Location = New System.Drawing.Point(165, 52)
        Me.EMPFNAME.Name = "EMPFNAME"
        Me.EMPFNAME.Size = New System.Drawing.Size(379, 22)
        Me.EMPFNAME.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(4, 9)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(279, 59)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "EMPLOYEE"
        '
        'DELETEMPLOYEE
        '
        Me.DELETEMPLOYEE.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DELETEMPLOYEE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETEMPLOYEE.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DELETEMPLOYEE.Location = New System.Drawing.Point(1038, 296)
        Me.DELETEMPLOYEE.Name = "DELETEMPLOYEE"
        Me.DELETEMPLOYEE.Size = New System.Drawing.Size(75, 33)
        Me.DELETEMPLOYEE.TabIndex = 61
        Me.DELETEMPLOYEE.Text = "Delete"
        Me.DELETEMPLOYEE.UseVisualStyleBackColor = False
        '
        'EMPBACK
        '
        Me.EMPBACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.EMPBACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPBACK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPBACK.Location = New System.Drawing.Point(957, 296)
        Me.EMPBACK.Name = "EMPBACK"
        Me.EMPBACK.Size = New System.Drawing.Size(75, 33)
        Me.EMPBACK.TabIndex = 62
        Me.EMPBACK.Text = "Back"
        Me.EMPBACK.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(1010, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(119, 112)
        Me.PictureBox1.TabIndex = 63
        Me.PictureBox1.TabStop = False
        '
        'EMPLOYEE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1140, 624)
        Me.Controls.Add(Me.EMPBACK)
        Me.Controls.Add(Me.DELETEMPLOYEE)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.DGVEMPLOYEE)
        Me.Controls.Add(Me.SAVEEMPLOYEE)
        Me.Controls.Add(Me.ADDEMPLOYEE)
        Me.Controls.Add(Me.SEARCHEMPLOYEE)
        Me.Controls.Add(Me.Panel2CAR)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "EMPLOYEE"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EMPLOYEE"
        CType(Me.DGVEMPLOYEE, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2CAR.ResumeLayout(False)
        Me.Panel2CAR.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Search As Label
    Friend WithEvents DGVEMPLOYEE As DataGridView
    Private WithEvents SAVEEMPLOYEE As Button
    Private WithEvents ADDEMPLOYEE As Button
    Private WithEvents SEARCHEMPLOYEE As TextBox
    Private WithEvents Panel2CAR As Panel
    Private WithEvents EMPTEL As TextBox
    Private WithEvents EMPADDRESS As TextBox
    Private WithEvents EMPID As TextBox
    Private WithEvents EMPEMAIL As TextBox
    Private WithEvents EMPMNAME As TextBox
    Private WithEvents EMPLNAME As TextBox
    Friend WithEvents LabelTNCAR As Label
    Friend WithEvents LabelACAR As Label
    Friend WithEvents LabelECAR As Label
    Friend WithEvents LabelLNCAR As Label
    Friend WithEvents LabelMNCAR As Label
    Friend WithEvents LabelFNCAR As Label
    Friend WithEvents LabelPNRNCAR As Label
    Private WithEvents EMPFNAME As TextBox
    Friend WithEvents Label2 As Label
    Private WithEvents DELETEMPLOYEE As Button
    Private WithEvents EMPBACK As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
