﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CUSTOMER
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Search = New System.Windows.Forms.Label()
        Me.DGVCUSTOMER = New System.Windows.Forms.DataGridView()
        Me.PASSPORTNO = New System.Windows.Forms.TextBox()
        Me.CUSDOB = New System.Windows.Forms.TextBox()
        Me.LabelPNCAR = New System.Windows.Forms.Label()
        Me.LabelDoBCAR = New System.Windows.Forms.Label()
        Me.CUSTEL = New System.Windows.Forms.TextBox()
        Me.CUSADDRESS = New System.Windows.Forms.TextBox()
        Me.PNRNO = New System.Windows.Forms.TextBox()
        Me.CUSEMAIL = New System.Windows.Forms.TextBox()
        Me.CUSMNAME = New System.Windows.Forms.TextBox()
        Me.CUSLNAME = New System.Windows.Forms.TextBox()
        Me.LabelTNCAR = New System.Windows.Forms.Label()
        Me.DELETECUS = New System.Windows.Forms.Button()
        Me.SAVECUS = New System.Windows.Forms.Button()
        Me.ADDCUS = New System.Windows.Forms.Button()
        Me.LabelACAR = New System.Windows.Forms.Label()
        Me.LabelECAR = New System.Windows.Forms.Label()
        Me.LabelLNCAR = New System.Windows.Forms.Label()
        Me.LabelFNCAR = New System.Windows.Forms.Label()
        Me.LabelPNRNCAR = New System.Windows.Forms.Label()
        Me.CUSFNAME = New System.Windows.Forms.TextBox()
        Me.SEARCHCUS = New System.Windows.Forms.TextBox()
        Me.Panel2CAR = New System.Windows.Forms.Panel()
        Me.LabelMNCAR = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CUSBACK = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.DGVCUSTOMER, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2CAR.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, -67)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(157, 29)
        Me.Label1.TabIndex = 45
        Me.Label1.Text = "CUSTOMER "
        '
        'Search
        '
        Me.Search.AutoSize = True
        Me.Search.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Search.Location = New System.Drawing.Point(20, 345)
        Me.Search.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(153, 26)
        Me.Search.TabIndex = 50
        Me.Search.Text = "Search PNRNO:"
        '
        'DGVCUSTOMER
        '
        Me.DGVCUSTOMER.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DGVCUSTOMER.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVCUSTOMER.Location = New System.Drawing.Point(10, 378)
        Me.DGVCUSTOMER.Margin = New System.Windows.Forms.Padding(2)
        Me.DGVCUSTOMER.Name = "DGVCUSTOMER"
        Me.DGVCUSTOMER.RowTemplate.Height = 24
        Me.DGVCUSTOMER.Size = New System.Drawing.Size(1118, 235)
        Me.DGVCUSTOMER.TabIndex = 49
        '
        'PASSPORTNO
        '
        Me.PASSPORTNO.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.PASSPORTNO.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PASSPORTNO.Location = New System.Drawing.Point(768, 137)
        Me.PASSPORTNO.Name = "PASSPORTNO"
        Me.PASSPORTNO.Size = New System.Drawing.Size(330, 22)
        Me.PASSPORTNO.TabIndex = 40
        '
        'CUSDOB
        '
        Me.CUSDOB.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSDOB.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSDOB.Location = New System.Drawing.Point(180, 175)
        Me.CUSDOB.Name = "CUSDOB"
        Me.CUSDOB.Size = New System.Drawing.Size(355, 22)
        Me.CUSDOB.TabIndex = 39
        '
        'LabelPNCAR
        '
        Me.LabelPNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelPNCAR.Location = New System.Drawing.Point(577, 133)
        Me.LabelPNCAR.Name = "LabelPNCAR"
        Me.LabelPNCAR.Size = New System.Drawing.Size(234, 26)
        Me.LabelPNCAR.TabIndex = 38
        Me.LabelPNCAR.Text = "Passport Number:"
        '
        'LabelDoBCAR
        '
        Me.LabelDoBCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDoBCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelDoBCAR.Location = New System.Drawing.Point(9, 171)
        Me.LabelDoBCAR.Name = "LabelDoBCAR"
        Me.LabelDoBCAR.Size = New System.Drawing.Size(177, 26)
        Me.LabelDoBCAR.TabIndex = 37
        Me.LabelDoBCAR.Text = "Date of Birth:"
        '
        'CUSTEL
        '
        Me.CUSTEL.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSTEL.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSTEL.Location = New System.Drawing.Point(768, 99)
        Me.CUSTEL.Name = "CUSTEL"
        Me.CUSTEL.Size = New System.Drawing.Size(330, 22)
        Me.CUSTEL.TabIndex = 36
        '
        'CUSADDRESS
        '
        Me.CUSADDRESS.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSADDRESS.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSADDRESS.Location = New System.Drawing.Point(665, 56)
        Me.CUSADDRESS.Name = "CUSADDRESS"
        Me.CUSADDRESS.Size = New System.Drawing.Size(433, 22)
        Me.CUSADDRESS.TabIndex = 35
        '
        'PNRNO
        '
        Me.PNRNO.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.PNRNO.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PNRNO.Location = New System.Drawing.Point(180, 20)
        Me.PNRNO.Name = "PNRNO"
        Me.PNRNO.Size = New System.Drawing.Size(355, 22)
        Me.PNRNO.TabIndex = 34
        '
        'CUSEMAIL
        '
        Me.CUSEMAIL.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSEMAIL.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSEMAIL.Location = New System.Drawing.Point(665, 20)
        Me.CUSEMAIL.Name = "CUSEMAIL"
        Me.CUSEMAIL.Size = New System.Drawing.Size(433, 22)
        Me.CUSEMAIL.TabIndex = 33
        '
        'CUSMNAME
        '
        Me.CUSMNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSMNAME.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSMNAME.Location = New System.Drawing.Point(181, 99)
        Me.CUSMNAME.Name = "CUSMNAME"
        Me.CUSMNAME.Size = New System.Drawing.Size(354, 22)
        Me.CUSMNAME.TabIndex = 32
        '
        'CUSLNAME
        '
        Me.CUSLNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSLNAME.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSLNAME.Location = New System.Drawing.Point(180, 137)
        Me.CUSLNAME.Name = "CUSLNAME"
        Me.CUSLNAME.Size = New System.Drawing.Size(355, 22)
        Me.CUSLNAME.TabIndex = 31
        '
        'LabelTNCAR
        '
        Me.LabelTNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelTNCAR.Location = New System.Drawing.Point(577, 95)
        Me.LabelTNCAR.Name = "LabelTNCAR"
        Me.LabelTNCAR.Size = New System.Drawing.Size(234, 26)
        Me.LabelTNCAR.TabIndex = 30
        Me.LabelTNCAR.Text = "Telephone Number:"
        '
        'DELETECUS
        '
        Me.DELETECUS.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DELETECUS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETECUS.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DELETECUS.Location = New System.Drawing.Point(1033, 340)
        Me.DELETECUS.Name = "DELETECUS"
        Me.DELETECUS.Size = New System.Drawing.Size(75, 33)
        Me.DELETECUS.TabIndex = 52
        Me.DELETECUS.Text = "Delete"
        Me.DELETECUS.UseVisualStyleBackColor = False
        '
        'SAVECUS
        '
        Me.SAVECUS.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SAVECUS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAVECUS.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SAVECUS.Location = New System.Drawing.Point(673, 340)
        Me.SAVECUS.Name = "SAVECUS"
        Me.SAVECUS.Size = New System.Drawing.Size(75, 33)
        Me.SAVECUS.TabIndex = 51
        Me.SAVECUS.Text = "Save"
        Me.SAVECUS.UseVisualStyleBackColor = False
        '
        'ADDCUS
        '
        Me.ADDCUS.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ADDCUS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDCUS.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ADDCUS.Location = New System.Drawing.Point(592, 340)
        Me.ADDCUS.Name = "ADDCUS"
        Me.ADDCUS.Size = New System.Drawing.Size(75, 33)
        Me.ADDCUS.TabIndex = 47
        Me.ADDCUS.Text = "Add"
        Me.ADDCUS.UseVisualStyleBackColor = False
        '
        'LabelACAR
        '
        Me.LabelACAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelACAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelACAR.Location = New System.Drawing.Point(577, 56)
        Me.LabelACAR.Name = "LabelACAR"
        Me.LabelACAR.Size = New System.Drawing.Size(119, 26)
        Me.LabelACAR.TabIndex = 29
        Me.LabelACAR.Text = "Address:"
        '
        'LabelECAR
        '
        Me.LabelECAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelECAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelECAR.Location = New System.Drawing.Point(577, 16)
        Me.LabelECAR.Name = "LabelECAR"
        Me.LabelECAR.Size = New System.Drawing.Size(90, 26)
        Me.LabelECAR.TabIndex = 28
        Me.LabelECAR.Text = "Email:"
        '
        'LabelLNCAR
        '
        Me.LabelLNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelLNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelLNCAR.Location = New System.Drawing.Point(10, 133)
        Me.LabelLNCAR.Name = "LabelLNCAR"
        Me.LabelLNCAR.Size = New System.Drawing.Size(166, 26)
        Me.LabelLNCAR.TabIndex = 27
        Me.LabelLNCAR.Text = "Last Name:"
        '
        'LabelFNCAR
        '
        Me.LabelFNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelFNCAR.Location = New System.Drawing.Point(9, 56)
        Me.LabelFNCAR.Name = "LabelFNCAR"
        Me.LabelFNCAR.Size = New System.Drawing.Size(149, 26)
        Me.LabelFNCAR.TabIndex = 25
        Me.LabelFNCAR.Text = "First Name:"
        '
        'LabelPNRNCAR
        '
        Me.LabelPNRNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPNRNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelPNRNCAR.Location = New System.Drawing.Point(9, 16)
        Me.LabelPNRNCAR.Name = "LabelPNRNCAR"
        Me.LabelPNRNCAR.Size = New System.Drawing.Size(166, 26)
        Me.LabelPNRNCAR.TabIndex = 24
        Me.LabelPNRNCAR.Text = "PNR Number:"
        '
        'CUSFNAME
        '
        Me.CUSFNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSFNAME.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSFNAME.Location = New System.Drawing.Point(180, 60)
        Me.CUSFNAME.Name = "CUSFNAME"
        Me.CUSFNAME.Size = New System.Drawing.Size(355, 22)
        Me.CUSFNAME.TabIndex = 0
        '
        'SEARCHCUS
        '
        Me.SEARCHCUS.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEARCHCUS.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEARCHCUS.Location = New System.Drawing.Point(189, 345)
        Me.SEARCHCUS.Name = "SEARCHCUS"
        Me.SEARCHCUS.Size = New System.Drawing.Size(354, 22)
        Me.SEARCHCUS.TabIndex = 53
        '
        'Panel2CAR
        '
        Me.Panel2CAR.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.Panel2CAR.Controls.Add(Me.CUSEMAIL)
        Me.Panel2CAR.Controls.Add(Me.PASSPORTNO)
        Me.Panel2CAR.Controls.Add(Me.CUSDOB)
        Me.Panel2CAR.Controls.Add(Me.LabelPNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelDoBCAR)
        Me.Panel2CAR.Controls.Add(Me.CUSTEL)
        Me.Panel2CAR.Controls.Add(Me.CUSADDRESS)
        Me.Panel2CAR.Controls.Add(Me.PNRNO)
        Me.Panel2CAR.Controls.Add(Me.CUSMNAME)
        Me.Panel2CAR.Controls.Add(Me.CUSLNAME)
        Me.Panel2CAR.Controls.Add(Me.LabelTNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelACAR)
        Me.Panel2CAR.Controls.Add(Me.LabelECAR)
        Me.Panel2CAR.Controls.Add(Me.LabelLNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelMNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelFNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelPNRNCAR)
        Me.Panel2CAR.Controls.Add(Me.CUSFNAME)
        Me.Panel2CAR.Location = New System.Drawing.Point(10, 115)
        Me.Panel2CAR.Name = "Panel2CAR"
        Me.Panel2CAR.Size = New System.Drawing.Size(1116, 215)
        Me.Panel2CAR.TabIndex = 48
        '
        'LabelMNCAR
        '
        Me.LabelMNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelMNCAR.Location = New System.Drawing.Point(10, 95)
        Me.LabelMNCAR.Name = "LabelMNCAR"
        Me.LabelMNCAR.Size = New System.Drawing.Size(165, 26)
        Me.LabelMNCAR.TabIndex = 26
        Me.LabelMNCAR.Text = "Middle Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(11, 9)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(314, 59)
        Me.Label2.TabIndex = 46
        Me.Label2.Text = "CUSTOMER "
        '
        'CUSBACK
        '
        Me.CUSBACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CUSBACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSBACK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSBACK.Location = New System.Drawing.Point(952, 340)
        Me.CUSBACK.Name = "CUSBACK"
        Me.CUSBACK.Size = New System.Drawing.Size(75, 33)
        Me.CUSBACK.TabIndex = 64
        Me.CUSBACK.Text = "Back"
        Me.CUSBACK.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(1010, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(119, 112)
        Me.PictureBox1.TabIndex = 71
        Me.PictureBox1.TabStop = False
        '
        'CUSTOMER
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1140, 624)
        Me.Controls.Add(Me.CUSBACK)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.DGVCUSTOMER)
        Me.Controls.Add(Me.DELETECUS)
        Me.Controls.Add(Me.SAVECUS)
        Me.Controls.Add(Me.ADDCUS)
        Me.Controls.Add(Me.SEARCHCUS)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel2CAR)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "CUSTOMER"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.DGVCUSTOMER, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2CAR.ResumeLayout(False)
        Me.Panel2CAR.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Search As Label
    Friend WithEvents DGVCUSTOMER As DataGridView
    Private WithEvents PASSPORTNO As TextBox
    Private WithEvents CUSDOB As TextBox
    Friend WithEvents LabelPNCAR As Label
    Friend WithEvents LabelDoBCAR As Label
    Private WithEvents CUSTEL As TextBox
    Private WithEvents CUSADDRESS As TextBox
    Private WithEvents PNRNO As TextBox
    Private WithEvents CUSEMAIL As TextBox
    Private WithEvents CUSMNAME As TextBox
    Private WithEvents CUSLNAME As TextBox
    Friend WithEvents LabelTNCAR As Label
    Private WithEvents DELETECUS As Button
    Private WithEvents SAVECUS As Button
    Private WithEvents ADDCUS As Button
    Friend WithEvents LabelACAR As Label
    Friend WithEvents LabelECAR As Label
    Friend WithEvents LabelLNCAR As Label
    Friend WithEvents LabelFNCAR As Label
    Friend WithEvents LabelPNRNCAR As Label
    Private WithEvents CUSFNAME As TextBox
    Private WithEvents SEARCHCUS As TextBox
    Private WithEvents Panel2CAR As Panel
    Friend WithEvents LabelMNCAR As Label
    Friend WithEvents Label2 As Label
    Private WithEvents CUSBACK As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
