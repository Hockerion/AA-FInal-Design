﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RESERVATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Search = New System.Windows.Forms.Label()
        Me.DGVRESERVATION = New System.Windows.Forms.DataGridView()
        Me.DELETERESERVATION = New System.Windows.Forms.Button()
        Me.SAVERESERVATION = New System.Windows.Forms.Button()
        Me.ADDRESERVATION = New System.Windows.Forms.Button()
        Me.SEARCHRESERVATION = New System.Windows.Forms.TextBox()
        Me.Panel2CAR = New System.Windows.Forms.Panel()
        Me.SEATID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FLIGHTID = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PNRNO = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RESID = New System.Windows.Forms.TextBox()
        Me.LabelFNCAR = New System.Windows.Forms.Label()
        Me.RESVID = New System.Windows.Forms.Label()
        Me.RESDATE = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RESBACK = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.DGVRESERVATION, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2CAR.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Search
        '
        Me.Search.AutoSize = True
        Me.Search.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Search.Location = New System.Drawing.Point(18, 280)
        Me.Search.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(153, 26)
        Me.Search.TabIndex = 66
        Me.Search.Text = "Search PNRNO:"
        '
        'DGVRESERVATION
        '
        Me.DGVRESERVATION.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DGVRESERVATION.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVRESERVATION.Location = New System.Drawing.Point(11, 317)
        Me.DGVRESERVATION.Margin = New System.Windows.Forms.Padding(2)
        Me.DGVRESERVATION.Name = "DGVRESERVATION"
        Me.DGVRESERVATION.RowTemplate.Height = 24
        Me.DGVRESERVATION.Size = New System.Drawing.Size(1117, 296)
        Me.DGVRESERVATION.TabIndex = 65
        '
        'DELETERESERVATION
        '
        Me.DELETERESERVATION.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DELETERESERVATION.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETERESERVATION.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DELETERESERVATION.Location = New System.Drawing.Point(1038, 274)
        Me.DELETERESERVATION.Name = "DELETERESERVATION"
        Me.DELETERESERVATION.Size = New System.Drawing.Size(75, 35)
        Me.DELETERESERVATION.TabIndex = 68
        Me.DELETERESERVATION.Text = "Delete"
        Me.DELETERESERVATION.UseVisualStyleBackColor = False
        '
        'SAVERESERVATION
        '
        Me.SAVERESERVATION.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SAVERESERVATION.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAVERESERVATION.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SAVERESERVATION.Location = New System.Drawing.Point(713, 274)
        Me.SAVERESERVATION.Name = "SAVERESERVATION"
        Me.SAVERESERVATION.Size = New System.Drawing.Size(75, 35)
        Me.SAVERESERVATION.TabIndex = 67
        Me.SAVERESERVATION.Text = "Save"
        Me.SAVERESERVATION.UseVisualStyleBackColor = False
        '
        'ADDRESERVATION
        '
        Me.ADDRESERVATION.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ADDRESERVATION.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDRESERVATION.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ADDRESERVATION.Location = New System.Drawing.Point(632, 274)
        Me.ADDRESERVATION.Name = "ADDRESERVATION"
        Me.ADDRESERVATION.Size = New System.Drawing.Size(75, 35)
        Me.ADDRESERVATION.TabIndex = 63
        Me.ADDRESERVATION.Text = "Add"
        Me.ADDRESERVATION.UseVisualStyleBackColor = False
        '
        'SEARCHRESERVATION
        '
        Me.SEARCHRESERVATION.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEARCHRESERVATION.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEARCHRESERVATION.Location = New System.Drawing.Point(222, 280)
        Me.SEARCHRESERVATION.Name = "SEARCHRESERVATION"
        Me.SEARCHRESERVATION.Size = New System.Drawing.Size(365, 22)
        Me.SEARCHRESERVATION.TabIndex = 69
        '
        'Panel2CAR
        '
        Me.Panel2CAR.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.Panel2CAR.Controls.Add(Me.SEATID)
        Me.Panel2CAR.Controls.Add(Me.Label4)
        Me.Panel2CAR.Controls.Add(Me.FLIGHTID)
        Me.Panel2CAR.Controls.Add(Me.Label3)
        Me.Panel2CAR.Controls.Add(Me.PNRNO)
        Me.Panel2CAR.Controls.Add(Me.Label1)
        Me.Panel2CAR.Controls.Add(Me.RESID)
        Me.Panel2CAR.Controls.Add(Me.LabelFNCAR)
        Me.Panel2CAR.Controls.Add(Me.RESVID)
        Me.Panel2CAR.Controls.Add(Me.RESDATE)
        Me.Panel2CAR.Location = New System.Drawing.Point(10, 115)
        Me.Panel2CAR.Name = "Panel2CAR"
        Me.Panel2CAR.Size = New System.Drawing.Size(1118, 153)
        Me.Panel2CAR.TabIndex = 64
        '
        'SEATID
        '
        Me.SEATID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEATID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEATID.Location = New System.Drawing.Point(746, 64)
        Me.SEATID.Name = "SEATID"
        Me.SEATID.Size = New System.Drawing.Size(357, 22)
        Me.SEATID.TabIndex = 40
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(617, 60)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 26)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Seat ID:"
        '
        'FLIGHTID
        '
        Me.FLIGHTID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.FLIGHTID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLIGHTID.Location = New System.Drawing.Point(746, 21)
        Me.FLIGHTID.Name = "FLIGHTID"
        Me.FLIGHTID.Size = New System.Drawing.Size(357, 22)
        Me.FLIGHTID.TabIndex = 38
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(617, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(111, 26)
        Me.Label3.TabIndex = 37
        Me.Label3.Text = "Flight ID:"
        '
        'PNRNO
        '
        Me.PNRNO.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.PNRNO.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PNRNO.Location = New System.Drawing.Point(212, 110)
        Me.PNRNO.Name = "PNRNO"
        Me.PNRNO.Size = New System.Drawing.Size(365, 22)
        Me.PNRNO.TabIndex = 36
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(8, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(111, 26)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "PNRNO:"
        '
        'RESID
        '
        Me.RESID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.RESID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RESID.Location = New System.Drawing.Point(212, 21)
        Me.RESID.Name = "RESID"
        Me.RESID.Size = New System.Drawing.Size(365, 22)
        Me.RESID.TabIndex = 34
        '
        'LabelFNCAR
        '
        Me.LabelFNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelFNCAR.Location = New System.Drawing.Point(8, 60)
        Me.LabelFNCAR.Name = "LabelFNCAR"
        Me.LabelFNCAR.Size = New System.Drawing.Size(193, 26)
        Me.LabelFNCAR.TabIndex = 25
        Me.LabelFNCAR.Text = "Reservation Date:"
        '
        'RESVID
        '
        Me.RESVID.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RESVID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.RESVID.Location = New System.Drawing.Point(8, 17)
        Me.RESVID.Name = "RESVID"
        Me.RESVID.Size = New System.Drawing.Size(186, 26)
        Me.RESVID.TabIndex = 24
        Me.RESVID.Text = "Reservation ID:"
        '
        'RESDATE
        '
        Me.RESDATE.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.RESDATE.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RESDATE.Location = New System.Drawing.Point(212, 64)
        Me.RESDATE.Name = "RESDATE"
        Me.RESDATE.Size = New System.Drawing.Size(365, 22)
        Me.RESDATE.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(11, 9)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(371, 59)
        Me.Label2.TabIndex = 62
        Me.Label2.Text = "RESERVATION"
        '
        'RESBACK
        '
        Me.RESBACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.RESBACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RESBACK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.RESBACK.Location = New System.Drawing.Point(957, 274)
        Me.RESBACK.Name = "RESBACK"
        Me.RESBACK.Size = New System.Drawing.Size(75, 35)
        Me.RESBACK.TabIndex = 70
        Me.RESBACK.Text = "Back"
        Me.RESBACK.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(1010, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(119, 112)
        Me.PictureBox1.TabIndex = 71
        Me.PictureBox1.TabStop = False
        '
        'RESERVATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1140, 624)
        Me.Controls.Add(Me.RESBACK)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.DGVRESERVATION)
        Me.Controls.Add(Me.DELETERESERVATION)
        Me.Controls.Add(Me.SAVERESERVATION)
        Me.Controls.Add(Me.ADDRESERVATION)
        Me.Controls.Add(Me.SEARCHRESERVATION)
        Me.Controls.Add(Me.Panel2CAR)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "RESERVATION"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "RESERVATION"
        CType(Me.DGVRESERVATION, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2CAR.ResumeLayout(False)
        Me.Panel2CAR.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Search As Label
    Friend WithEvents DGVRESERVATION As DataGridView
    Private WithEvents DELETERESERVATION As Button
    Private WithEvents SAVERESERVATION As Button
    Private WithEvents ADDRESERVATION As Button
    Private WithEvents SEARCHRESERVATION As TextBox
    Private WithEvents Panel2CAR As Panel
    Private WithEvents RESID As TextBox
    Friend WithEvents LabelFNCAR As Label
    Friend WithEvents RESVID As Label
    Private WithEvents RESDATE As TextBox
    Friend WithEvents Label2 As Label
    Private WithEvents FLIGHTID As TextBox
    Friend WithEvents Label3 As Label
    Private WithEvents PNRNO As TextBox
    Friend WithEvents Label1 As Label
    Private WithEvents RESBACK As Button
    Private WithEvents SEATID As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
