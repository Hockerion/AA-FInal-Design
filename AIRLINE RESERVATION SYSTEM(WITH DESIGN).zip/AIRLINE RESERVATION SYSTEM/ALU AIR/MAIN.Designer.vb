﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MAIN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.LOGOUT = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.EMPLOYEE = New System.Windows.Forms.Button()
        Me.CUSTOMER = New System.Windows.Forms.Button()
        Me.SEAT = New System.Windows.Forms.Button()
        Me.FLIGHT = New System.Windows.Forms.Button()
        Me.REBOOKFLI = New System.Windows.Forms.Button()
        Me.CANCELFLI = New System.Windows.Forms.Button()
        Me.AIRCRAFT = New System.Windows.Forms.Button()
        Me.TICKET = New System.Windows.Forms.Button()
        Me.RESERVATION = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LOGOUT
        '
        Me.LOGOUT.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.LOGOUT.Font = New System.Drawing.Font("Franklin Gothic Medium", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LOGOUT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LOGOUT.Location = New System.Drawing.Point(908, 93)
        Me.LOGOUT.Margin = New System.Windows.Forms.Padding(2)
        Me.LOGOUT.Name = "LOGOUT"
        Me.LOGOUT.Size = New System.Drawing.Size(111, 44)
        Me.LOGOUT.TabIndex = 16
        Me.LOGOUT.Text = "Logout"
        Me.LOGOUT.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Navy
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Controls.Add(Me.Panel1)
        Me.Panel2.Controls.Add(Me.LOGOUT)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Location = New System.Drawing.Point(0, -1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1048, 150)
        Me.Panel2.TabIndex = 17
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Location = New System.Drawing.Point(30, 2)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(184, 167)
        Me.Panel1.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.Button1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Book_Flight_Finale
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(631, 405)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(192, 166)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "BOOK FLIGHT"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = False
        '
        'EMPLOYEE
        '
        Me.EMPLOYEE.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.EMPLOYEE.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Employee_Finale
        Me.EMPLOYEE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.EMPLOYEE.Font = New System.Drawing.Font("Franklin Gothic Medium", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMPLOYEE.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.EMPLOYEE.Location = New System.Drawing.Point(239, 210)
        Me.EMPLOYEE.Margin = New System.Windows.Forms.Padding(2)
        Me.EMPLOYEE.Name = "EMPLOYEE"
        Me.EMPLOYEE.Size = New System.Drawing.Size(192, 166)
        Me.EMPLOYEE.TabIndex = 3
        Me.EMPLOYEE.Text = "EMPLOYEE"
        Me.EMPLOYEE.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.EMPLOYEE.UseVisualStyleBackColor = False
        '
        'CUSTOMER
        '
        Me.CUSTOMER.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.CUSTOMER.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Customer_Finale
        Me.CUSTOMER.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.CUSTOMER.Font = New System.Drawing.Font("Franklin Gothic Medium", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSTOMER.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSTOMER.Location = New System.Drawing.Point(239, 405)
        Me.CUSTOMER.Margin = New System.Windows.Forms.Padding(2)
        Me.CUSTOMER.Name = "CUSTOMER"
        Me.CUSTOMER.Size = New System.Drawing.Size(192, 166)
        Me.CUSTOMER.TabIndex = 2
        Me.CUSTOMER.Text = "CUSTOMER"
        Me.CUSTOMER.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CUSTOMER.UseVisualStyleBackColor = False
        '
        'SEAT
        '
        Me.SEAT.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.SEAT.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Seat_FInale
        Me.SEAT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SEAT.Font = New System.Drawing.Font("Franklin Gothic Medium", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEAT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEAT.Location = New System.Drawing.Point(435, 405)
        Me.SEAT.Margin = New System.Windows.Forms.Padding(2)
        Me.SEAT.Name = "SEAT"
        Me.SEAT.Size = New System.Drawing.Size(192, 166)
        Me.SEAT.TabIndex = 13
        Me.SEAT.Text = "SEAT"
        Me.SEAT.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.SEAT.UseVisualStyleBackColor = False
        '
        'FLIGHT
        '
        Me.FLIGHT.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.FLIGHT.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Flight_Finale
        Me.FLIGHT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.FLIGHT.Font = New System.Drawing.Font("Franklin Gothic Medium", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLIGHT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.FLIGHT.Location = New System.Drawing.Point(30, 210)
        Me.FLIGHT.Margin = New System.Windows.Forms.Padding(2)
        Me.FLIGHT.Name = "FLIGHT"
        Me.FLIGHT.Size = New System.Drawing.Size(192, 166)
        Me.FLIGHT.TabIndex = 10
        Me.FLIGHT.Text = "FLIGHT"
        Me.FLIGHT.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.FLIGHT.UseVisualStyleBackColor = False
        '
        'REBOOKFLI
        '
        Me.REBOOKFLI.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.REBOOKFLI.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Rebook_Flight_Finale
        Me.REBOOKFLI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.REBOOKFLI.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.REBOOKFLI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.REBOOKFLI.Location = New System.Drawing.Point(827, 210)
        Me.REBOOKFLI.Margin = New System.Windows.Forms.Padding(2)
        Me.REBOOKFLI.Name = "REBOOKFLI"
        Me.REBOOKFLI.Size = New System.Drawing.Size(192, 166)
        Me.REBOOKFLI.TabIndex = 15
        Me.REBOOKFLI.Text = "REBOOK FLIGHT"
        Me.REBOOKFLI.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.REBOOKFLI.UseVisualStyleBackColor = False
        '
        'CANCELFLI
        '
        Me.CANCELFLI.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.CANCELFLI.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Cancel_Flight_Finale
        Me.CANCELFLI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CANCELFLI.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CANCELFLI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CANCELFLI.Location = New System.Drawing.Point(827, 405)
        Me.CANCELFLI.Margin = New System.Windows.Forms.Padding(2)
        Me.CANCELFLI.Name = "CANCELFLI"
        Me.CANCELFLI.Size = New System.Drawing.Size(192, 166)
        Me.CANCELFLI.TabIndex = 14
        Me.CANCELFLI.Text = "CANCEL FLIGHT"
        Me.CANCELFLI.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CANCELFLI.UseVisualStyleBackColor = False
        '
        'AIRCRAFT
        '
        Me.AIRCRAFT.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.AIRCRAFT.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Aircraft_Finale
        Me.AIRCRAFT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.AIRCRAFT.Font = New System.Drawing.Font("Franklin Gothic Medium", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AIRCRAFT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.AIRCRAFT.Location = New System.Drawing.Point(30, 405)
        Me.AIRCRAFT.Margin = New System.Windows.Forms.Padding(2)
        Me.AIRCRAFT.Name = "AIRCRAFT"
        Me.AIRCRAFT.Size = New System.Drawing.Size(192, 166)
        Me.AIRCRAFT.TabIndex = 11
        Me.AIRCRAFT.Text = "AIRCRAFT"
        Me.AIRCRAFT.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.AIRCRAFT.UseVisualStyleBackColor = False
        '
        'TICKET
        '
        Me.TICKET.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.TICKET.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Ticket_Finale_2
        Me.TICKET.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TICKET.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TICKET.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.TICKET.Location = New System.Drawing.Point(631, 210)
        Me.TICKET.Margin = New System.Windows.Forms.Padding(2)
        Me.TICKET.Name = "TICKET"
        Me.TICKET.Size = New System.Drawing.Size(192, 166)
        Me.TICKET.TabIndex = 8
        Me.TICKET.Text = "TICKET"
        Me.TICKET.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.TICKET.UseVisualStyleBackColor = False
        '
        'RESERVATION
        '
        Me.RESERVATION.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.RESERVATION.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.Reservation_Finale
        Me.RESERVATION.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.RESERVATION.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RESERVATION.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.RESERVATION.Location = New System.Drawing.Point(435, 210)
        Me.RESERVATION.Margin = New System.Windows.Forms.Padding(2)
        Me.RESERVATION.Name = "RESERVATION"
        Me.RESERVATION.Size = New System.Drawing.Size(192, 166)
        Me.RESERVATION.TabIndex = 6
        Me.RESERVATION.Text = "RESERVATION"
        Me.RESERVATION.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.RESERVATION.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.ALU_AIR
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(219, 58)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(258, 92)
        Me.PictureBox1.TabIndex = 17
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AIR
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(473, 58)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(258, 92)
        Me.PictureBox2.TabIndex = 18
        Me.PictureBox2.TabStop = False
        '
        'MAIN
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1047, 600)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.EMPLOYEE)
        Me.Controls.Add(Me.CUSTOMER)
        Me.Controls.Add(Me.SEAT)
        Me.Controls.Add(Me.FLIGHT)
        Me.Controls.Add(Me.REBOOKFLI)
        Me.Controls.Add(Me.CANCELFLI)
        Me.Controls.Add(Me.AIRCRAFT)
        Me.Controls.Add(Me.TICKET)
        Me.Controls.Add(Me.RESERVATION)
        Me.ForeColor = System.Drawing.Color.Blue
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "MAIN"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MAIN"
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents EMPLOYEE As Button
    Friend WithEvents RESERVATION As Button
    Friend WithEvents TICKET As Button
    Friend WithEvents FLIGHT As Button
    Friend WithEvents AIRCRAFT As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents SEAT As Button
    Friend WithEvents REBOOKFLI As Button
    Friend WithEvents LOGOUT As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents CANCELFLI As Button
    Friend WithEvents CUSTOMER As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
End Class
