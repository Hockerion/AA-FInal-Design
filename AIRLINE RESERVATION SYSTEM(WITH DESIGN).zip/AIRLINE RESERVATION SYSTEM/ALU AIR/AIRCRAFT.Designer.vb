﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AIRCRAFT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Search = New System.Windows.Forms.Label()
        Me.DGVAIRCRAFT = New System.Windows.Forms.DataGridView()
        Me.DELETEAIRCRAFT = New System.Windows.Forms.Button()
        Me.SAVEAIRCRAFT = New System.Windows.Forms.Button()
        Me.ADDAIRCRAFT = New System.Windows.Forms.Button()
        Me.SEARCHAIRCRAFT = New System.Windows.Forms.TextBox()
        Me.Panel2CAR = New System.Windows.Forms.Panel()
        Me.AIRCRAFTID = New System.Windows.Forms.TextBox()
        Me.LabelFNCAR = New System.Windows.Forms.Label()
        Me.AIRCRAFTNo = New System.Windows.Forms.Label()
        Me.CAPACITY = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.AIRBACK = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.DGVAIRCRAFT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2CAR.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Search
        '
        Me.Search.AutoSize = True
        Me.Search.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Search.Location = New System.Drawing.Point(24, 218)
        Me.Search.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(117, 26)
        Me.Search.TabIndex = 58
        Me.Search.Text = "SEARCH ID:"
        '
        'DGVAIRCRAFT
        '
        Me.DGVAIRCRAFT.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DGVAIRCRAFT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVAIRCRAFT.Location = New System.Drawing.Point(11, 294)
        Me.DGVAIRCRAFT.Margin = New System.Windows.Forms.Padding(2)
        Me.DGVAIRCRAFT.Name = "DGVAIRCRAFT"
        Me.DGVAIRCRAFT.RowTemplate.Height = 24
        Me.DGVAIRCRAFT.Size = New System.Drawing.Size(545, 296)
        Me.DGVAIRCRAFT.TabIndex = 57
        '
        'DELETEAIRCRAFT
        '
        Me.DELETEAIRCRAFT.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DELETEAIRCRAFT.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETEAIRCRAFT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DELETEAIRCRAFT.Location = New System.Drawing.Point(456, 255)
        Me.DELETEAIRCRAFT.Name = "DELETEAIRCRAFT"
        Me.DELETEAIRCRAFT.Size = New System.Drawing.Size(86, 34)
        Me.DELETEAIRCRAFT.TabIndex = 60
        Me.DELETEAIRCRAFT.Text = "Delete"
        Me.DELETEAIRCRAFT.UseVisualStyleBackColor = False
        '
        'SAVEAIRCRAFT
        '
        Me.SAVEAIRCRAFT.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SAVEAIRCRAFT.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAVEAIRCRAFT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SAVEAIRCRAFT.Location = New System.Drawing.Point(108, 255)
        Me.SAVEAIRCRAFT.Name = "SAVEAIRCRAFT"
        Me.SAVEAIRCRAFT.Size = New System.Drawing.Size(75, 34)
        Me.SAVEAIRCRAFT.TabIndex = 59
        Me.SAVEAIRCRAFT.Text = "Save"
        Me.SAVEAIRCRAFT.UseVisualStyleBackColor = False
        '
        'ADDAIRCRAFT
        '
        Me.ADDAIRCRAFT.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ADDAIRCRAFT.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDAIRCRAFT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ADDAIRCRAFT.Location = New System.Drawing.Point(27, 255)
        Me.ADDAIRCRAFT.Name = "ADDAIRCRAFT"
        Me.ADDAIRCRAFT.Size = New System.Drawing.Size(75, 34)
        Me.ADDAIRCRAFT.TabIndex = 55
        Me.ADDAIRCRAFT.Text = "Add"
        Me.ADDAIRCRAFT.UseVisualStyleBackColor = False
        '
        'SEARCHAIRCRAFT
        '
        Me.SEARCHAIRCRAFT.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEARCHAIRCRAFT.Location = New System.Drawing.Point(189, 218)
        Me.SEARCHAIRCRAFT.Name = "SEARCHAIRCRAFT"
        Me.SEARCHAIRCRAFT.Size = New System.Drawing.Size(353, 20)
        Me.SEARCHAIRCRAFT.TabIndex = 61
        '
        'Panel2CAR
        '
        Me.Panel2CAR.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.Panel2CAR.Controls.Add(Me.AIRCRAFTID)
        Me.Panel2CAR.Controls.Add(Me.LabelFNCAR)
        Me.Panel2CAR.Controls.Add(Me.AIRCRAFTNo)
        Me.Panel2CAR.Controls.Add(Me.CAPACITY)
        Me.Panel2CAR.Location = New System.Drawing.Point(11, 110)
        Me.Panel2CAR.Name = "Panel2CAR"
        Me.Panel2CAR.Size = New System.Drawing.Size(544, 102)
        Me.Panel2CAR.TabIndex = 56
        '
        'AIRCRAFTID
        '
        Me.AIRCRAFTID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.AIRCRAFTID.Location = New System.Drawing.Point(177, 20)
        Me.AIRCRAFTID.Name = "AIRCRAFTID"
        Me.AIRCRAFTID.Size = New System.Drawing.Size(354, 20)
        Me.AIRCRAFTID.TabIndex = 34
        '
        'LabelFNCAR
        '
        Me.LabelFNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelFNCAR.Location = New System.Drawing.Point(11, 63)
        Me.LabelFNCAR.Name = "LabelFNCAR"
        Me.LabelFNCAR.Size = New System.Drawing.Size(111, 26)
        Me.LabelFNCAR.TabIndex = 25
        Me.LabelFNCAR.Text = "CAPACITY:"
        '
        'AIRCRAFTNo
        '
        Me.AIRCRAFTNo.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AIRCRAFTNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.AIRCRAFTNo.Location = New System.Drawing.Point(11, 20)
        Me.AIRCRAFTNo.Name = "AIRCRAFTNo"
        Me.AIRCRAFTNo.Size = New System.Drawing.Size(160, 26)
        Me.AIRCRAFTNo.TabIndex = 24
        Me.AIRCRAFTNo.Text = "AIRCRAFT ID:"
        '
        'CAPACITY
        '
        Me.CAPACITY.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CAPACITY.Location = New System.Drawing.Point(177, 63)
        Me.CAPACITY.Name = "CAPACITY"
        Me.CAPACITY.Size = New System.Drawing.Size(354, 20)
        Me.CAPACITY.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(11, 9)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(271, 59)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "AIRCRAFT"
        '
        'AIRBACK
        '
        Me.AIRBACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AIRBACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AIRBACK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.AIRBACK.Location = New System.Drawing.Point(375, 255)
        Me.AIRBACK.Name = "AIRBACK"
        Me.AIRBACK.Size = New System.Drawing.Size(75, 34)
        Me.AIRBACK.TabIndex = 63
        Me.AIRBACK.Text = "Back"
        Me.AIRBACK.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(437, -8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(119, 112)
        Me.PictureBox1.TabIndex = 81
        Me.PictureBox1.TabStop = False
        '
        'AIRCRAFT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(567, 600)
        Me.Controls.Add(Me.AIRBACK)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.DGVAIRCRAFT)
        Me.Controls.Add(Me.DELETEAIRCRAFT)
        Me.Controls.Add(Me.SAVEAIRCRAFT)
        Me.Controls.Add(Me.ADDAIRCRAFT)
        Me.Controls.Add(Me.SEARCHAIRCRAFT)
        Me.Controls.Add(Me.Panel2CAR)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "AIRCRAFT"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AIRCRAFT"
        CType(Me.DGVAIRCRAFT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2CAR.ResumeLayout(False)
        Me.Panel2CAR.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Search As Label
    Friend WithEvents DGVAIRCRAFT As DataGridView
    Private WithEvents DELETEAIRCRAFT As Button
    Private WithEvents SAVEAIRCRAFT As Button
    Private WithEvents ADDAIRCRAFT As Button
    Private WithEvents SEARCHAIRCRAFT As TextBox
    Private WithEvents Panel2CAR As Panel
    Private WithEvents AIRCRAFTID As TextBox
    Friend WithEvents LabelFNCAR As Label
    Friend WithEvents AIRCRAFTNo As Label
    Private WithEvents CAPACITY As TextBox
    Friend WithEvents Label2 As Label
    Private WithEvents AIRBACK As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
