﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FLIGHT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Search = New System.Windows.Forms.Label()
        Me.DGVFLIGHT = New System.Windows.Forms.DataGridView()
        Me.SAVEFLI = New System.Windows.Forms.Button()
        Me.ADDFLI = New System.Windows.Forms.Button()
        Me.SEARCHFLI = New System.Windows.Forms.TextBox()
        Me.Panel2CAR = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ARRRTIME = New System.Windows.Forms.TextBox()
        Me.DEPPTIME = New System.Windows.Forms.TextBox()
        Me.ARRDATE = New System.Windows.Forms.DateTimePicker()
        Me.DEPDATE = New System.Windows.Forms.DateTimePicker()
        Me.AIRCRAFTID = New System.Windows.Forms.TextBox()
        Me.AIRCRAFTNO = New System.Windows.Forms.Label()
        Me.FARE = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.DURATION = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelPNCAR = New System.Windows.Forms.Label()
        Me.LabelDoBCAR = New System.Windows.Forms.Label()
        Me.FLIGHTID = New System.Windows.Forms.TextBox()
        Me.ROUTE = New System.Windows.Forms.TextBox()
        Me.DESTINATION = New System.Windows.Forms.TextBox()
        Me.FLIGHTTYPE = New System.Windows.Forms.TextBox()
        Me.LabelTNCAR = New System.Windows.Forms.Label()
        Me.LabelACAR = New System.Windows.Forms.Label()
        Me.LabelECAR = New System.Windows.Forms.Label()
        Me.LabelLNCAR = New System.Windows.Forms.Label()
        Me.LabelMNCAR = New System.Windows.Forms.Label()
        Me.LabelFNCAR = New System.Windows.Forms.Label()
        Me.LabelPNRNCAR = New System.Windows.Forms.Label()
        Me.ORIGIN = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DELETEFLI = New System.Windows.Forms.Button()
        Me.FLIBACK = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.DGVFLIGHT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2CAR.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Search
        '
        Me.Search.AutoSize = True
        Me.Search.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Search.Location = New System.Drawing.Point(22, 360)
        Me.Search.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(187, 26)
        Me.Search.TabIndex = 58
        Me.Search.Text = "Search Destination:"
        '
        'DGVFLIGHT
        '
        Me.DGVFLIGHT.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DGVFLIGHT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVFLIGHT.Location = New System.Drawing.Point(10, 397)
        Me.DGVFLIGHT.Margin = New System.Windows.Forms.Padding(2)
        Me.DGVFLIGHT.Name = "DGVFLIGHT"
        Me.DGVFLIGHT.RowTemplate.Height = 24
        Me.DGVFLIGHT.Size = New System.Drawing.Size(1118, 216)
        Me.DGVFLIGHT.TabIndex = 57
        '
        'SAVEFLI
        '
        Me.SAVEFLI.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SAVEFLI.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAVEFLI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SAVEFLI.Location = New System.Drawing.Point(829, 359)
        Me.SAVEFLI.Name = "SAVEFLI"
        Me.SAVEFLI.Size = New System.Drawing.Size(75, 33)
        Me.SAVEFLI.TabIndex = 59
        Me.SAVEFLI.Text = "Save"
        Me.SAVEFLI.UseVisualStyleBackColor = False
        '
        'ADDFLI
        '
        Me.ADDFLI.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ADDFLI.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDFLI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ADDFLI.Location = New System.Drawing.Point(748, 359)
        Me.ADDFLI.Name = "ADDFLI"
        Me.ADDFLI.Size = New System.Drawing.Size(75, 33)
        Me.ADDFLI.TabIndex = 55
        Me.ADDFLI.Text = "Add"
        Me.ADDFLI.UseVisualStyleBackColor = False
        '
        'SEARCHFLI
        '
        Me.SEARCHFLI.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEARCHFLI.Location = New System.Drawing.Point(214, 366)
        Me.SEARCHFLI.Name = "SEARCHFLI"
        Me.SEARCHFLI.Size = New System.Drawing.Size(309, 20)
        Me.SEARCHFLI.TabIndex = 60
        '
        'Panel2CAR
        '
        Me.Panel2CAR.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.Panel2CAR.Controls.Add(Me.Label5)
        Me.Panel2CAR.Controls.Add(Me.ARRRTIME)
        Me.Panel2CAR.Controls.Add(Me.DEPPTIME)
        Me.Panel2CAR.Controls.Add(Me.ARRDATE)
        Me.Panel2CAR.Controls.Add(Me.DEPDATE)
        Me.Panel2CAR.Controls.Add(Me.AIRCRAFTID)
        Me.Panel2CAR.Controls.Add(Me.AIRCRAFTNO)
        Me.Panel2CAR.Controls.Add(Me.FARE)
        Me.Panel2CAR.Controls.Add(Me.Label3)
        Me.Panel2CAR.Controls.Add(Me.DURATION)
        Me.Panel2CAR.Controls.Add(Me.Label1)
        Me.Panel2CAR.Controls.Add(Me.LabelPNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelDoBCAR)
        Me.Panel2CAR.Controls.Add(Me.FLIGHTID)
        Me.Panel2CAR.Controls.Add(Me.ROUTE)
        Me.Panel2CAR.Controls.Add(Me.DESTINATION)
        Me.Panel2CAR.Controls.Add(Me.FLIGHTTYPE)
        Me.Panel2CAR.Controls.Add(Me.LabelTNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelACAR)
        Me.Panel2CAR.Controls.Add(Me.LabelECAR)
        Me.Panel2CAR.Controls.Add(Me.LabelLNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelMNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelFNCAR)
        Me.Panel2CAR.Controls.Add(Me.LabelPNRNCAR)
        Me.Panel2CAR.Controls.Add(Me.ORIGIN)
        Me.Panel2CAR.Location = New System.Drawing.Point(10, 115)
        Me.Panel2CAR.Name = "Panel2CAR"
        Me.Panel2CAR.Size = New System.Drawing.Size(1116, 234)
        Me.Panel2CAR.TabIndex = 56
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(817, 162)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(23, 26)
        Me.Label5.TabIndex = 68
        Me.Label5.Text = "h"
        '
        'ARRRTIME
        '
        Me.ARRRTIME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ARRRTIME.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ARRRTIME.Location = New System.Drawing.Point(736, 126)
        Me.ARRRTIME.Name = "ARRRTIME"
        Me.ARRRTIME.Size = New System.Drawing.Size(365, 22)
        Me.ARRRTIME.TabIndex = 67
        Me.ARRRTIME.Text = "00:00:00"
        '
        'DEPPTIME
        '
        Me.DEPPTIME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DEPPTIME.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DEPPTIME.Location = New System.Drawing.Point(736, 93)
        Me.DEPPTIME.Name = "DEPPTIME"
        Me.DEPPTIME.Size = New System.Drawing.Size(365, 22)
        Me.DEPPTIME.TabIndex = 66
        Me.DEPPTIME.Text = "00:00:00"
        '
        'ARRDATE
        '
        Me.ARRDATE.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ARRDATE.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ARRDATE.Location = New System.Drawing.Point(736, 58)
        Me.ARRDATE.Margin = New System.Windows.Forms.Padding(2)
        Me.ARRDATE.Name = "ARRDATE"
        Me.ARRDATE.Size = New System.Drawing.Size(365, 22)
        Me.ARRDATE.TabIndex = 65
        '
        'DEPDATE
        '
        Me.DEPDATE.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DEPDATE.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DEPDATE.Location = New System.Drawing.Point(736, 22)
        Me.DEPDATE.Margin = New System.Windows.Forms.Padding(2)
        Me.DEPDATE.Name = "DEPDATE"
        Me.DEPDATE.Size = New System.Drawing.Size(365, 22)
        Me.DEPDATE.TabIndex = 64
        '
        'AIRCRAFTID
        '
        Me.AIRCRAFTID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.AIRCRAFTID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AIRCRAFTID.Location = New System.Drawing.Point(736, 204)
        Me.AIRCRAFTID.Name = "AIRCRAFTID"
        Me.AIRCRAFTID.Size = New System.Drawing.Size(365, 22)
        Me.AIRCRAFTID.TabIndex = 63
        '
        'AIRCRAFTNO
        '
        Me.AIRCRAFTNO.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AIRCRAFTNO.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.AIRCRAFTNO.Location = New System.Drawing.Point(564, 200)
        Me.AIRCRAFTNO.Name = "AIRCRAFTNO"
        Me.AIRCRAFTNO.Size = New System.Drawing.Size(138, 26)
        Me.AIRCRAFTNO.TabIndex = 62
        Me.AIRCRAFTNO.Text = "Aircraft ID:"
        '
        'FARE
        '
        Me.FARE.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.FARE.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FARE.Location = New System.Drawing.Point(148, 204)
        Me.FARE.Name = "FARE"
        Me.FARE.Size = New System.Drawing.Size(365, 22)
        Me.FARE.TabIndex = 44
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(12, 200)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 26)
        Me.Label3.TabIndex = 43
        Me.Label3.Text = "Fare:"
        '
        'DURATION
        '
        Me.DURATION.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DURATION.Enabled = False
        Me.DURATION.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DURATION.Location = New System.Drawing.Point(736, 166)
        Me.DURATION.Name = "DURATION"
        Me.DURATION.Size = New System.Drawing.Size(76, 22)
        Me.DURATION.TabIndex = 42
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(564, 162)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(122, 26)
        Me.Label1.TabIndex = 41
        Me.Label1.Text = "Duration:"
        '
        'LabelPNCAR
        '
        Me.LabelPNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelPNCAR.Location = New System.Drawing.Point(564, 89)
        Me.LabelPNCAR.Name = "LabelPNCAR"
        Me.LabelPNCAR.Size = New System.Drawing.Size(180, 26)
        Me.LabelPNCAR.TabIndex = 38
        Me.LabelPNCAR.Text = "Departure Time:"
        '
        'LabelDoBCAR
        '
        Me.LabelDoBCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDoBCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelDoBCAR.Location = New System.Drawing.Point(564, 122)
        Me.LabelDoBCAR.Name = "LabelDoBCAR"
        Me.LabelDoBCAR.Size = New System.Drawing.Size(138, 26)
        Me.LabelDoBCAR.TabIndex = 37
        Me.LabelDoBCAR.Text = "Arrival Time:"
        '
        'FLIGHTID
        '
        Me.FLIGHTID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.FLIGHTID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLIGHTID.Location = New System.Drawing.Point(148, 20)
        Me.FLIGHTID.Name = "FLIGHTID"
        Me.FLIGHTID.Size = New System.Drawing.Size(365, 22)
        Me.FLIGHTID.TabIndex = 34
        '
        'ROUTE
        '
        Me.ROUTE.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ROUTE.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ROUTE.Location = New System.Drawing.Point(146, 166)
        Me.ROUTE.Name = "ROUTE"
        Me.ROUTE.Size = New System.Drawing.Size(365, 22)
        Me.ROUTE.TabIndex = 33
        '
        'DESTINATION
        '
        Me.DESTINATION.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DESTINATION.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DESTINATION.Location = New System.Drawing.Point(148, 93)
        Me.DESTINATION.Name = "DESTINATION"
        Me.DESTINATION.Size = New System.Drawing.Size(365, 22)
        Me.DESTINATION.TabIndex = 32
        '
        'FLIGHTTYPE
        '
        Me.FLIGHTTYPE.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.FLIGHTTYPE.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLIGHTTYPE.Location = New System.Drawing.Point(146, 126)
        Me.FLIGHTTYPE.Name = "FLIGHTTYPE"
        Me.FLIGHTTYPE.Size = New System.Drawing.Size(365, 22)
        Me.FLIGHTTYPE.TabIndex = 31
        '
        'LabelTNCAR
        '
        Me.LabelTNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelTNCAR.Location = New System.Drawing.Point(564, 54)
        Me.LabelTNCAR.Name = "LabelTNCAR"
        Me.LabelTNCAR.Size = New System.Drawing.Size(138, 26)
        Me.LabelTNCAR.TabIndex = 30
        Me.LabelTNCAR.Text = "Arrival Date:"
        '
        'LabelACAR
        '
        Me.LabelACAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelACAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelACAR.Location = New System.Drawing.Point(561, 20)
        Me.LabelACAR.Name = "LabelACAR"
        Me.LabelACAR.Size = New System.Drawing.Size(141, 26)
        Me.LabelACAR.TabIndex = 29
        Me.LabelACAR.Text = "Departure Date:"
        '
        'LabelECAR
        '
        Me.LabelECAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelECAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelECAR.Location = New System.Drawing.Point(10, 162)
        Me.LabelECAR.Name = "LabelECAR"
        Me.LabelECAR.Size = New System.Drawing.Size(91, 26)
        Me.LabelECAR.TabIndex = 28
        Me.LabelECAR.Text = "Route:"
        '
        'LabelLNCAR
        '
        Me.LabelLNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelLNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelLNCAR.Location = New System.Drawing.Point(10, 122)
        Me.LabelLNCAR.Name = "LabelLNCAR"
        Me.LabelLNCAR.Size = New System.Drawing.Size(130, 26)
        Me.LabelLNCAR.TabIndex = 27
        Me.LabelLNCAR.Text = "Flight Type:"
        '
        'LabelMNCAR
        '
        Me.LabelMNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelMNCAR.Location = New System.Drawing.Point(10, 89)
        Me.LabelMNCAR.Name = "LabelMNCAR"
        Me.LabelMNCAR.Size = New System.Drawing.Size(132, 26)
        Me.LabelMNCAR.TabIndex = 26
        Me.LabelMNCAR.Text = "Destination:"
        '
        'LabelFNCAR
        '
        Me.LabelFNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelFNCAR.Location = New System.Drawing.Point(10, 56)
        Me.LabelFNCAR.Name = "LabelFNCAR"
        Me.LabelFNCAR.Size = New System.Drawing.Size(111, 26)
        Me.LabelFNCAR.TabIndex = 25
        Me.LabelFNCAR.Text = "Origin:"
        '
        'LabelPNRNCAR
        '
        Me.LabelPNRNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPNRNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelPNRNCAR.Location = New System.Drawing.Point(12, 20)
        Me.LabelPNRNCAR.Name = "LabelPNRNCAR"
        Me.LabelPNRNCAR.Size = New System.Drawing.Size(111, 26)
        Me.LabelPNRNCAR.TabIndex = 24
        Me.LabelPNRNCAR.Text = "Flight ID:"
        '
        'ORIGIN
        '
        Me.ORIGIN.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ORIGIN.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ORIGIN.Location = New System.Drawing.Point(146, 60)
        Me.ORIGIN.Name = "ORIGIN"
        Me.ORIGIN.Size = New System.Drawing.Size(365, 22)
        Me.ORIGIN.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(11, 9)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(204, 59)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "FLIGHT"
        '
        'DELETEFLI
        '
        Me.DELETEFLI.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DELETEFLI.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETEFLI.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DELETEFLI.Location = New System.Drawing.Point(1038, 359)
        Me.DELETEFLI.Name = "DELETEFLI"
        Me.DELETEFLI.Size = New System.Drawing.Size(75, 33)
        Me.DELETEFLI.TabIndex = 61
        Me.DELETEFLI.Text = "Delete"
        Me.DELETEFLI.UseVisualStyleBackColor = False
        '
        'FLIBACK
        '
        Me.FLIBACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FLIBACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLIBACK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.FLIBACK.Location = New System.Drawing.Point(957, 359)
        Me.FLIBACK.Name = "FLIBACK"
        Me.FLIBACK.Size = New System.Drawing.Size(75, 33)
        Me.FLIBACK.TabIndex = 63
        Me.FLIBACK.Text = "Back"
        Me.FLIBACK.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(1010, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(119, 112)
        Me.PictureBox1.TabIndex = 64
        Me.PictureBox1.TabStop = False
        '
        'FLIGHT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1140, 624)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.FLIBACK)
        Me.Controls.Add(Me.DELETEFLI)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.DGVFLIGHT)
        Me.Controls.Add(Me.SAVEFLI)
        Me.Controls.Add(Me.ADDFLI)
        Me.Controls.Add(Me.SEARCHFLI)
        Me.Controls.Add(Me.Panel2CAR)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "FLIGHT"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FLIGHT"
        CType(Me.DGVFLIGHT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2CAR.ResumeLayout(False)
        Me.Panel2CAR.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Search As Label
    Friend WithEvents DGVFLIGHT As DataGridView
    Private WithEvents SAVEFLI As Button
    Private WithEvents ADDFLI As Button
    Private WithEvents SEARCHFLI As TextBox
    Private WithEvents Panel2CAR As Panel
    Friend WithEvents LabelPNCAR As Label
    Friend WithEvents LabelDoBCAR As Label
    Private WithEvents FLIGHTID As TextBox
    Private WithEvents ROUTE As TextBox
    Private WithEvents DESTINATION As TextBox
    Private WithEvents FLIGHTTYPE As TextBox
    Friend WithEvents LabelTNCAR As Label
    Friend WithEvents LabelACAR As Label
    Friend WithEvents LabelECAR As Label
    Friend WithEvents LabelLNCAR As Label
    Friend WithEvents LabelMNCAR As Label
    Friend WithEvents LabelFNCAR As Label
    Friend WithEvents LabelPNRNCAR As Label
    Private WithEvents ORIGIN As TextBox
    Friend WithEvents Label2 As Label
    Private WithEvents FARE As TextBox
    Friend WithEvents Label3 As Label
    Private WithEvents DURATION As TextBox
    Friend WithEvents Label1 As Label
    Private WithEvents DELETEFLI As Button
    Private WithEvents AIRCRAFTID As TextBox
    Friend WithEvents AIRCRAFTNO As Label
    Private WithEvents FLIBACK As Button
    Friend WithEvents DEPDATE As DateTimePicker
    Friend WithEvents ARRDATE As DateTimePicker
    Friend WithEvents ARRTIME As DateTimePicker
    Friend WithEvents DEPTIME As DateTimePicker
    Private WithEvents ARRRTIME As TextBox
    Private WithEvents DEPPTIME As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
