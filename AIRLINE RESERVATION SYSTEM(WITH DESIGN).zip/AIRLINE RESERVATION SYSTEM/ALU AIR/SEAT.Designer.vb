﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Seat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SEATBACK = New System.Windows.Forms.Button()
        Me.Search = New System.Windows.Forms.Label()
        Me.DGVSEAT = New System.Windows.Forms.DataGridView()
        Me.DELETESEAT = New System.Windows.Forms.Button()
        Me.SAVESEAT = New System.Windows.Forms.Button()
        Me.ADDSEAT = New System.Windows.Forms.Button()
        Me.SEARCHSEAT = New System.Windows.Forms.TextBox()
        Me.Panel2CAR = New System.Windows.Forms.Panel()
        Me.STATUS = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SEATID = New System.Windows.Forms.TextBox()
        Me.LabelFNCAR = New System.Windows.Forms.Label()
        Me.AIRCRAFTNo = New System.Windows.Forms.Label()
        Me.CLASSS = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.DGVSEAT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2CAR.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SEATBACK
        '
        Me.SEATBACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SEATBACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEATBACK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEATBACK.Location = New System.Drawing.Point(385, 280)
        Me.SEATBACK.Name = "SEATBACK"
        Me.SEATBACK.Size = New System.Drawing.Size(75, 31)
        Me.SEATBACK.TabIndex = 79
        Me.SEATBACK.Text = "Back"
        Me.SEATBACK.UseVisualStyleBackColor = False
        '
        'Search
        '
        Me.Search.AutoSize = True
        Me.Search.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Search.Location = New System.Drawing.Point(21, 240)
        Me.Search.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(132, 26)
        Me.Search.TabIndex = 75
        Me.Search.Text = "Search Class:"
        '
        'DGVSEAT
        '
        Me.DGVSEAT.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DGVSEAT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVSEAT.Location = New System.Drawing.Point(10, 326)
        Me.DGVSEAT.Margin = New System.Windows.Forms.Padding(2)
        Me.DGVSEAT.Name = "DGVSEAT"
        Me.DGVSEAT.RowTemplate.Height = 24
        Me.DGVSEAT.Size = New System.Drawing.Size(546, 263)
        Me.DGVSEAT.TabIndex = 74
        '
        'DELETESEAT
        '
        Me.DELETESEAT.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DELETESEAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETESEAT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DELETESEAT.Location = New System.Drawing.Point(466, 280)
        Me.DELETESEAT.Name = "DELETESEAT"
        Me.DELETESEAT.Size = New System.Drawing.Size(75, 31)
        Me.DELETESEAT.TabIndex = 77
        Me.DELETESEAT.Text = "Delete"
        Me.DELETESEAT.UseVisualStyleBackColor = False
        '
        'SAVESEAT
        '
        Me.SAVESEAT.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SAVESEAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAVESEAT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SAVESEAT.Location = New System.Drawing.Point(100, 280)
        Me.SAVESEAT.Name = "SAVESEAT"
        Me.SAVESEAT.Size = New System.Drawing.Size(75, 31)
        Me.SAVESEAT.TabIndex = 76
        Me.SAVESEAT.Text = "Save"
        Me.SAVESEAT.UseVisualStyleBackColor = False
        '
        'ADDSEAT
        '
        Me.ADDSEAT.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ADDSEAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDSEAT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ADDSEAT.Location = New System.Drawing.Point(19, 280)
        Me.ADDSEAT.Name = "ADDSEAT"
        Me.ADDSEAT.Size = New System.Drawing.Size(75, 31)
        Me.ADDSEAT.TabIndex = 72
        Me.ADDSEAT.Text = "Add"
        Me.ADDSEAT.UseVisualStyleBackColor = False
        '
        'SEARCHSEAT
        '
        Me.SEARCHSEAT.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEARCHSEAT.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEARCHSEAT.Location = New System.Drawing.Point(158, 240)
        Me.SEARCHSEAT.Name = "SEARCHSEAT"
        Me.SEARCHSEAT.Size = New System.Drawing.Size(383, 22)
        Me.SEARCHSEAT.TabIndex = 78
        '
        'Panel2CAR
        '
        Me.Panel2CAR.Controls.Add(Me.STATUS)
        Me.Panel2CAR.Controls.Add(Me.Label1)
        Me.Panel2CAR.Controls.Add(Me.SEATID)
        Me.Panel2CAR.Controls.Add(Me.LabelFNCAR)
        Me.Panel2CAR.Controls.Add(Me.AIRCRAFTNo)
        Me.Panel2CAR.Controls.Add(Me.CLASSS)
        Me.Panel2CAR.Location = New System.Drawing.Point(10, 93)
        Me.Panel2CAR.Name = "Panel2CAR"
        Me.Panel2CAR.Size = New System.Drawing.Size(545, 141)
        Me.Panel2CAR.TabIndex = 73
        '
        'STATUS
        '
        Me.STATUS.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.STATUS.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.STATUS.Location = New System.Drawing.Point(148, 106)
        Me.STATUS.Name = "STATUS"
        Me.STATUS.Size = New System.Drawing.Size(383, 22)
        Me.STATUS.TabIndex = 36
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(11, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(111, 26)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Status:"
        '
        'SEATID
        '
        Me.SEATID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEATID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEATID.Location = New System.Drawing.Point(148, 22)
        Me.SEATID.Name = "SEATID"
        Me.SEATID.Size = New System.Drawing.Size(383, 22)
        Me.SEATID.TabIndex = 34
        '
        'LabelFNCAR
        '
        Me.LabelFNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelFNCAR.Location = New System.Drawing.Point(11, 65)
        Me.LabelFNCAR.Name = "LabelFNCAR"
        Me.LabelFNCAR.Size = New System.Drawing.Size(111, 26)
        Me.LabelFNCAR.TabIndex = 25
        Me.LabelFNCAR.Text = "Class:"
        '
        'AIRCRAFTNo
        '
        Me.AIRCRAFTNo.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AIRCRAFTNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.AIRCRAFTNo.Location = New System.Drawing.Point(11, 22)
        Me.AIRCRAFTNo.Name = "AIRCRAFTNo"
        Me.AIRCRAFTNo.Size = New System.Drawing.Size(111, 26)
        Me.AIRCRAFTNo.TabIndex = 24
        Me.AIRCRAFTNo.Text = "Seat ID:"
        '
        'CLASSS
        '
        Me.CLASSS.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CLASSS.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CLASSS.Location = New System.Drawing.Point(148, 65)
        Me.CLASSS.Name = "CLASSS"
        Me.CLASSS.Size = New System.Drawing.Size(383, 22)
        Me.CLASSS.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(11, 9)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(148, 59)
        Me.Label2.TabIndex = 71
        Me.Label2.Text = "SEAT"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(437, -8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(119, 112)
        Me.PictureBox1.TabIndex = 80
        Me.PictureBox1.TabStop = False
        '
        'Seat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(567, 600)
        Me.Controls.Add(Me.SEATBACK)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.DGVSEAT)
        Me.Controls.Add(Me.DELETESEAT)
        Me.Controls.Add(Me.SAVESEAT)
        Me.Controls.Add(Me.ADDSEAT)
        Me.Controls.Add(Me.SEARCHSEAT)
        Me.Controls.Add(Me.Panel2CAR)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Seat"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Seat"
        CType(Me.DGVSEAT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2CAR.ResumeLayout(False)
        Me.Panel2CAR.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents SEATBACK As Button
    Friend WithEvents Search As Label
    Friend WithEvents DGVSEAT As DataGridView
    Private WithEvents DELETESEAT As Button
    Private WithEvents SAVESEAT As Button
    Private WithEvents ADDSEAT As Button
    Private WithEvents SEARCHSEAT As TextBox
    Private WithEvents Panel2CAR As Panel
    Private WithEvents STATUS As TextBox
    Friend WithEvents Label1 As Label
    Private WithEvents SEATID As TextBox
    Friend WithEvents LabelFNCAR As Label
    Friend WithEvents AIRCRAFTNo As Label
    Private WithEvents CLASSS As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
