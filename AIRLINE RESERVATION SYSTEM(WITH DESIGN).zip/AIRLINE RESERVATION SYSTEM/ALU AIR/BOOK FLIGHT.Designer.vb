﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Book_Flight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PNRNOGEN = New System.Windows.Forms.Button()
        Me.PASSPORTNO = New System.Windows.Forms.TextBox()
        Me.CUSDOB = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CUSTEL = New System.Windows.Forms.TextBox()
        Me.CUSADDRESS = New System.Windows.Forms.TextBox()
        Me.PNRNO = New System.Windows.Forms.TextBox()
        Me.CUSEMAIL = New System.Windows.Forms.TextBox()
        Me.CUSMNAME = New System.Windows.Forms.TextBox()
        Me.CUSLNAME = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CUSFNAME = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SEATID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.FLIGHTID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.BOOK = New System.Windows.Forms.Button()
        Me.BACK = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(4, 7)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(363, 59)
        Me.Label1.TabIndex = 71
        Me.Label1.Text = "BOOK FLIGHT"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.PNRNOGEN)
        Me.GroupBox1.Controls.Add(Me.PASSPORTNO)
        Me.GroupBox1.Controls.Add(Me.CUSDOB)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.CUSTEL)
        Me.GroupBox1.Controls.Add(Me.CUSADDRESS)
        Me.GroupBox1.Controls.Add(Me.PNRNO)
        Me.GroupBox1.Controls.Add(Me.CUSEMAIL)
        Me.GroupBox1.Controls.Add(Me.CUSMNAME)
        Me.GroupBox1.Controls.Add(Me.CUSLNAME)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.CUSFNAME)
        Me.GroupBox1.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(11, 105)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(1120, 264)
        Me.GroupBox1.TabIndex = 73
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personal Information"
        '
        'PNRNOGEN
        '
        Me.PNRNOGEN.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.PNRNOGEN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PNRNOGEN.ForeColor = System.Drawing.SystemColors.Control
        Me.PNRNOGEN.Location = New System.Drawing.Point(20, 37)
        Me.PNRNOGEN.Margin = New System.Windows.Forms.Padding(2)
        Me.PNRNOGEN.Name = "PNRNOGEN"
        Me.PNRNOGEN.Size = New System.Drawing.Size(125, 34)
        Me.PNRNOGEN.TabIndex = 79
        Me.PNRNOGEN.Text = "PNR Number: "
        Me.PNRNOGEN.UseVisualStyleBackColor = False
        '
        'PASSPORTNO
        '
        Me.PASSPORTNO.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.PASSPORTNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PASSPORTNO.Location = New System.Drawing.Point(760, 216)
        Me.PASSPORTNO.Name = "PASSPORTNO"
        Me.PASSPORTNO.Size = New System.Drawing.Size(342, 22)
        Me.PASSPORTNO.TabIndex = 58
        '
        'CUSDOB
        '
        Me.CUSDOB.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSDOB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSDOB.Location = New System.Drawing.Point(170, 216)
        Me.CUSDOB.Name = "CUSDOB"
        Me.CUSDOB.Size = New System.Drawing.Size(365, 22)
        Me.CUSDOB.TabIndex = 57
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(567, 212)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(138, 26)
        Me.Label2.TabIndex = 56
        Me.Label2.Text = "Passport Number:"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(15, 212)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(160, 26)
        Me.Label3.TabIndex = 55
        Me.Label3.Text = "Date of Birth:"
        '
        'CUSTEL
        '
        Me.CUSTEL.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSTEL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSTEL.Location = New System.Drawing.Point(760, 175)
        Me.CUSTEL.Name = "CUSTEL"
        Me.CUSTEL.Size = New System.Drawing.Size(342, 22)
        Me.CUSTEL.TabIndex = 54
        '
        'CUSADDRESS
        '
        Me.CUSADDRESS.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSADDRESS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSADDRESS.Location = New System.Drawing.Point(760, 135)
        Me.CUSADDRESS.Name = "CUSADDRESS"
        Me.CUSADDRESS.Size = New System.Drawing.Size(342, 22)
        Me.CUSADDRESS.TabIndex = 53
        '
        'PNRNO
        '
        Me.PNRNO.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.PNRNO.Enabled = False
        Me.PNRNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PNRNO.Location = New System.Drawing.Point(170, 43)
        Me.PNRNO.Name = "PNRNO"
        Me.PNRNO.Size = New System.Drawing.Size(364, 22)
        Me.PNRNO.TabIndex = 52
        Me.PNRNO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CUSEMAIL
        '
        Me.CUSEMAIL.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSEMAIL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSEMAIL.Location = New System.Drawing.Point(760, 94)
        Me.CUSEMAIL.Name = "CUSEMAIL"
        Me.CUSEMAIL.Size = New System.Drawing.Size(342, 22)
        Me.CUSEMAIL.TabIndex = 51
        '
        'CUSMNAME
        '
        Me.CUSMNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSMNAME.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSMNAME.Location = New System.Drawing.Point(169, 135)
        Me.CUSMNAME.Name = "CUSMNAME"
        Me.CUSMNAME.Size = New System.Drawing.Size(365, 22)
        Me.CUSMNAME.TabIndex = 50
        '
        'CUSLNAME
        '
        Me.CUSLNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSLNAME.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSLNAME.Location = New System.Drawing.Point(170, 175)
        Me.CUSLNAME.Name = "CUSLNAME"
        Me.CUSLNAME.Size = New System.Drawing.Size(365, 22)
        Me.CUSLNAME.TabIndex = 49
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(567, 171)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(205, 26)
        Me.Label4.TabIndex = 48
        Me.Label4.Text = "Telephone Number:"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(567, 135)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(113, 26)
        Me.Label5.TabIndex = 47
        Me.Label5.Text = "Address:"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(567, 90)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(82, 26)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Email:"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(15, 171)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(130, 26)
        Me.Label7.TabIndex = 45
        Me.Label7.Text = "Last Name:"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(15, 131)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(160, 26)
        Me.Label8.TabIndex = 44
        Me.Label8.Text = "Middle Name:"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(15, 90)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(130, 26)
        Me.Label9.TabIndex = 43
        Me.Label9.Text = "First Name:"
        '
        'CUSFNAME
        '
        Me.CUSFNAME.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.CUSFNAME.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CUSFNAME.Location = New System.Drawing.Point(169, 92)
        Me.CUSFNAME.Name = "CUSFNAME"
        Me.CUSFNAME.Size = New System.Drawing.Size(365, 22)
        Me.CUSFNAME.TabIndex = 41
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.TextBox12)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.TextBox10)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.TextBox11)
        Me.GroupBox2.Font = New System.Drawing.Font("Myanmar Text", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(552, 396)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(577, 197)
        Me.GroupBox2.TabIndex = 74
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Payment"
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label15.Location = New System.Drawing.Point(19, 143)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(125, 26)
        Me.Label15.TabIndex = 45
        Me.Label15.Text = "CVC:"
        '
        'TextBox12
        '
        Me.TextBox12.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.TextBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(191, 143)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(365, 22)
        Me.TextBox12.TabIndex = 44
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(15, 93)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(177, 26)
        Me.Label13.TabIndex = 43
        Me.Label13.Text = "Card Expiration:"
        '
        'TextBox10
        '
        Me.TextBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.TextBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(191, 93)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(365, 22)
        Me.TextBox10.TabIndex = 42
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label14.Location = New System.Drawing.Point(15, 47)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(147, 26)
        Me.Label14.TabIndex = 41
        Me.Label14.Text = "Card Number:"
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.TextBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.Location = New System.Drawing.Point(191, 42)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(365, 22)
        Me.TextBox11.TabIndex = 40
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.Button2)
        Me.GroupBox3.Controls.Add(Me.SEATID)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.FLIGHTID)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.GroupBox3.Location = New System.Drawing.Point(11, 407)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Size = New System.Drawing.Size(528, 146)
        Me.GroupBox3.TabIndex = 75
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Flight "
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.Control
        Me.Button2.Location = New System.Drawing.Point(391, 92)
        Me.Button2.Margin = New System.Windows.Forms.Padding(2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(122, 34)
        Me.Button2.TabIndex = 46
        Me.Button2.Text = "View Seats"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'SEATID
        '
        Me.SEATID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEATID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEATID.Location = New System.Drawing.Point(115, 98)
        Me.SEATID.Name = "SEATID"
        Me.SEATID.Size = New System.Drawing.Size(253, 22)
        Me.SEATID.TabIndex = 44
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(17, 94)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(111, 26)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Seat ID:"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.Control
        Me.Button1.Location = New System.Drawing.Point(391, 51)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(122, 34)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "View Flights"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'FLIGHTID
        '
        Me.FLIGHTID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.FLIGHTID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLIGHTID.Location = New System.Drawing.Point(115, 51)
        Me.FLIGHTID.Name = "FLIGHTID"
        Me.FLIGHTID.Size = New System.Drawing.Size(253, 22)
        Me.FLIGHTID.TabIndex = 42
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(16, 47)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(111, 26)
        Me.Label12.TabIndex = 41
        Me.Label12.Text = "Flight ID:"
        '
        'BOOK
        '
        Me.BOOK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BOOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BOOK.ForeColor = System.Drawing.SystemColors.Control
        Me.BOOK.Location = New System.Drawing.Point(347, 568)
        Me.BOOK.Margin = New System.Windows.Forms.Padding(2)
        Me.BOOK.Name = "BOOK"
        Me.BOOK.Size = New System.Drawing.Size(92, 34)
        Me.BOOK.TabIndex = 76
        Me.BOOK.Text = "Book"
        Me.BOOK.UseVisualStyleBackColor = False
        '
        'BACK
        '
        Me.BACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BACK.ForeColor = System.Drawing.SystemColors.Control
        Me.BACK.Location = New System.Drawing.Point(240, 568)
        Me.BACK.Margin = New System.Windows.Forms.Padding(2)
        Me.BACK.Name = "BACK"
        Me.BACK.Size = New System.Drawing.Size(92, 34)
        Me.BACK.TabIndex = 78
        Me.BACK.Text = "Back"
        Me.BACK.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(1010, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(119, 112)
        Me.PictureBox1.TabIndex = 89
        Me.PictureBox1.TabStop = False
        '
        'Book_Flight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1140, 624)
        Me.Controls.Add(Me.BACK)
        Me.Controls.Add(Me.BOOK)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Book_Flight"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Book_Flight"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Private WithEvents PASSPORTNO As TextBox
    Private WithEvents CUSDOB As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Private WithEvents CUSTEL As TextBox
    Private WithEvents CUSADDRESS As TextBox
    Private WithEvents PNRNO As TextBox
    Private WithEvents CUSEMAIL As TextBox
    Private WithEvents CUSMNAME As TextBox
    Private WithEvents CUSLNAME As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Private WithEvents CUSFNAME As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Private WithEvents SEATID As TextBox
    Friend WithEvents Label11 As Label
    Private WithEvents FLIGHTID As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Private WithEvents TextBox10 As TextBox
    Friend WithEvents Label14 As Label
    Private WithEvents TextBox11 As TextBox
    Friend WithEvents Label15 As Label
    Private WithEvents TextBox12 As TextBox
    Friend WithEvents BOOK As Button
    Friend WithEvents BACK As Button
    Friend WithEvents PNRNOGEN As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
