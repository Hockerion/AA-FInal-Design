﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TICKET
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Search = New System.Windows.Forms.Label()
        Me.DGVTICKET = New System.Windows.Forms.DataGridView()
        Me.DELETETICKET = New System.Windows.Forms.Button()
        Me.SAVETICKET = New System.Windows.Forms.Button()
        Me.ADDTICKET = New System.Windows.Forms.Button()
        Me.SEARCHTICKET = New System.Windows.Forms.TextBox()
        Me.Panel2CAR = New System.Windows.Forms.Panel()
        Me.SEATID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FLIGHTID = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PNRNO = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TICKETID = New System.Windows.Forms.TextBox()
        Me.LabelFNCAR = New System.Windows.Forms.Label()
        Me.AIRCRAFTNo = New System.Windows.Forms.Label()
        Me.DATEISSUED = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TICKBACK = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.DGVTICKET, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2CAR.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Search
        '
        Me.Search.AutoSize = True
        Me.Search.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Search.Location = New System.Drawing.Point(21, 262)
        Me.Search.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(153, 26)
        Me.Search.TabIndex = 74
        Me.Search.Text = "Search PNRNO:"
        '
        'DGVTICKET
        '
        Me.DGVTICKET.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DGVTICKET.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVTICKET.Location = New System.Drawing.Point(11, 303)
        Me.DGVTICKET.Margin = New System.Windows.Forms.Padding(2)
        Me.DGVTICKET.Name = "DGVTICKET"
        Me.DGVTICKET.RowTemplate.Height = 24
        Me.DGVTICKET.Size = New System.Drawing.Size(1118, 310)
        Me.DGVTICKET.TabIndex = 73
        '
        'DELETETICKET
        '
        Me.DELETETICKET.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DELETETICKET.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DELETETICKET.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DELETETICKET.Location = New System.Drawing.Point(1031, 261)
        Me.DELETETICKET.Name = "DELETETICKET"
        Me.DELETETICKET.Size = New System.Drawing.Size(75, 33)
        Me.DELETETICKET.TabIndex = 76
        Me.DELETETICKET.Text = "Delete"
        Me.DELETETICKET.UseVisualStyleBackColor = False
        '
        'SAVETICKET
        '
        Me.SAVETICKET.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SAVETICKET.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAVETICKET.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SAVETICKET.Location = New System.Drawing.Point(641, 261)
        Me.SAVETICKET.Name = "SAVETICKET"
        Me.SAVETICKET.Size = New System.Drawing.Size(75, 33)
        Me.SAVETICKET.TabIndex = 75
        Me.SAVETICKET.Text = "Save"
        Me.SAVETICKET.UseVisualStyleBackColor = False
        '
        'ADDTICKET
        '
        Me.ADDTICKET.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ADDTICKET.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADDTICKET.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.ADDTICKET.Location = New System.Drawing.Point(560, 261)
        Me.ADDTICKET.Name = "ADDTICKET"
        Me.ADDTICKET.Size = New System.Drawing.Size(75, 33)
        Me.ADDTICKET.TabIndex = 71
        Me.ADDTICKET.Text = "Add"
        Me.ADDTICKET.UseVisualStyleBackColor = False
        '
        'SEARCHTICKET
        '
        Me.SEARCHTICKET.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEARCHTICKET.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEARCHTICKET.Location = New System.Drawing.Point(182, 266)
        Me.SEARCHTICKET.Name = "SEARCHTICKET"
        Me.SEARCHTICKET.Size = New System.Drawing.Size(314, 22)
        Me.SEARCHTICKET.TabIndex = 77
        '
        'Panel2CAR
        '
        Me.Panel2CAR.BackColor = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.Panel2CAR.Controls.Add(Me.SEATID)
        Me.Panel2CAR.Controls.Add(Me.Label4)
        Me.Panel2CAR.Controls.Add(Me.FLIGHTID)
        Me.Panel2CAR.Controls.Add(Me.Label3)
        Me.Panel2CAR.Controls.Add(Me.PNRNO)
        Me.Panel2CAR.Controls.Add(Me.Label1)
        Me.Panel2CAR.Controls.Add(Me.TICKETID)
        Me.Panel2CAR.Controls.Add(Me.LabelFNCAR)
        Me.Panel2CAR.Controls.Add(Me.AIRCRAFTNo)
        Me.Panel2CAR.Controls.Add(Me.DATEISSUED)
        Me.Panel2CAR.Location = New System.Drawing.Point(10, 115)
        Me.Panel2CAR.Name = "Panel2CAR"
        Me.Panel2CAR.Size = New System.Drawing.Size(1118, 140)
        Me.Panel2CAR.TabIndex = 72
        '
        'SEATID
        '
        Me.SEATID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.SEATID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEATID.Location = New System.Drawing.Point(648, 63)
        Me.SEATID.Name = "SEATID"
        Me.SEATID.Size = New System.Drawing.Size(448, 22)
        Me.SEATID.TabIndex = 40
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(545, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 26)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Seat ID:"
        '
        'FLIGHTID
        '
        Me.FLIGHTID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.FLIGHTID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLIGHTID.Location = New System.Drawing.Point(648, 20)
        Me.FLIGHTID.Name = "FLIGHTID"
        Me.FLIGHTID.Size = New System.Drawing.Size(448, 22)
        Me.FLIGHTID.TabIndex = 38
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(545, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(123, 26)
        Me.Label3.TabIndex = 37
        Me.Label3.Text = "Flight ID:"
        '
        'PNRNO
        '
        Me.PNRNO.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.PNRNO.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PNRNO.Location = New System.Drawing.Point(172, 106)
        Me.PNRNO.Name = "PNRNO"
        Me.PNRNO.Size = New System.Drawing.Size(314, 22)
        Me.PNRNO.TabIndex = 36
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(11, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(165, 26)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "PNR Number:"
        '
        'TICKETID
        '
        Me.TICKETID.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.TICKETID.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TICKETID.Location = New System.Drawing.Point(172, 20)
        Me.TICKETID.Name = "TICKETID"
        Me.TICKETID.Size = New System.Drawing.Size(314, 22)
        Me.TICKETID.TabIndex = 34
        '
        'LabelFNCAR
        '
        Me.LabelFNCAR.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFNCAR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LabelFNCAR.Location = New System.Drawing.Point(11, 63)
        Me.LabelFNCAR.Name = "LabelFNCAR"
        Me.LabelFNCAR.Size = New System.Drawing.Size(153, 26)
        Me.LabelFNCAR.TabIndex = 25
        Me.LabelFNCAR.Text = "Date Issued:"
        '
        'AIRCRAFTNo
        '
        Me.AIRCRAFTNo.Font = New System.Drawing.Font("Franklin Gothic Medium", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AIRCRAFTNo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.AIRCRAFTNo.Location = New System.Drawing.Point(11, 20)
        Me.AIRCRAFTNo.Name = "AIRCRAFTNo"
        Me.AIRCRAFTNo.Size = New System.Drawing.Size(131, 26)
        Me.AIRCRAFTNo.TabIndex = 24
        Me.AIRCRAFTNo.Text = "Ticket ID:"
        '
        'DATEISSUED
        '
        Me.DATEISSUED.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.DATEISSUED.Font = New System.Drawing.Font("Franklin Gothic Medium", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DATEISSUED.Location = New System.Drawing.Point(172, 63)
        Me.DATEISSUED.Name = "DATEISSUED"
        Me.DATEISSUED.Size = New System.Drawing.Size(314, 22)
        Me.DATEISSUED.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(11, 9)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(203, 59)
        Me.Label2.TabIndex = 70
        Me.Label2.Text = "TICKET"
        '
        'TICKBACK
        '
        Me.TICKBACK.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TICKBACK.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TICKBACK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.TICKBACK.Location = New System.Drawing.Point(950, 261)
        Me.TICKBACK.Name = "TICKBACK"
        Me.TICKBACK.Size = New System.Drawing.Size(75, 33)
        Me.TICKBACK.TabIndex = 78
        Me.TICKBACK.Text = "Back"
        Me.TICKBACK.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.CUSTOMER_and_FLIGHT.My.Resources.Resources.AA_NL_11_Imperatora
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(1010, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(119, 112)
        Me.PictureBox1.TabIndex = 79
        Me.PictureBox1.TabStop = False
        '
        'TICKET
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(79, Byte), Integer), CType(CType(244, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1140, 624)
        Me.Controls.Add(Me.TICKBACK)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.DGVTICKET)
        Me.Controls.Add(Me.DELETETICKET)
        Me.Controls.Add(Me.SAVETICKET)
        Me.Controls.Add(Me.ADDTICKET)
        Me.Controls.Add(Me.SEARCHTICKET)
        Me.Controls.Add(Me.Panel2CAR)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "TICKET"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TICKET"
        CType(Me.DGVTICKET, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2CAR.ResumeLayout(False)
        Me.Panel2CAR.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Search As Label
    Friend WithEvents DGVTICKET As DataGridView
    Private WithEvents DELETETICKET As Button
    Private WithEvents SAVETICKET As Button
    Private WithEvents ADDTICKET As Button
    Private WithEvents SEARCHTICKET As TextBox
    Private WithEvents Panel2CAR As Panel
    Private WithEvents PNRNO As TextBox
    Friend WithEvents Label1 As Label
    Private WithEvents TICKETID As TextBox
    Friend WithEvents LabelFNCAR As Label
    Friend WithEvents AIRCRAFTNo As Label
    Private WithEvents DATEISSUED As TextBox
    Friend WithEvents Label2 As Label
    Private WithEvents TICKBACK As Button
    Private WithEvents SEATID As TextBox
    Friend WithEvents Label4 As Label
    Private WithEvents FLIGHTID As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
